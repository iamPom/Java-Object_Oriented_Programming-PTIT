// code:
// name:
package ktra1;

/**
 *
 * @author Pom
 */
public class SoNguyen {
    
}
