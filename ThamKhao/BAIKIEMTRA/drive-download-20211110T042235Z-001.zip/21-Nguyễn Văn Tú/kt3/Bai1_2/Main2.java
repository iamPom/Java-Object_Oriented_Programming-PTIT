package Bai1_2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class Main2 {

	public static void main(String[] args) {
		
		try {
		BufferedReader br = new BufferedReader(new FileReader("src/Bai1_2/in.txt"));
                
                
		PrintWriter pr = new PrintWriter(new File("src/Bai1_2/out.txt"));
		String line = null;
		int col = Integer.parseInt(line = br.readLine());
		while((line = br.readLine() ) != null) {
			String [] num = line.trim().split("\\s+");
			int sum = 0;
			for(String i : num) {
                            
				sum += Integer.parseInt(i);
			}
			
			pr.print(sum +" ");
		}
		pr.close();
		br.close();
		
		}
                
		catch(FileNotFoundException e) {
			System.out.println(e);
		}
		catch(IOException e) {
			System.out.println(e);
		}
                
		
	}

}
