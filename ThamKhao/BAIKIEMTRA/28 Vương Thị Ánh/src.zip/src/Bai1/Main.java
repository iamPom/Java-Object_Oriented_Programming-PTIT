/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai1;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Main {
   
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n=Integer.parseInt(sc.nextLine());
        
        CountDown t1=new CountDown(n);
        Color t2=new Color(n);
        t1.start();
        t2.start();
    }
} 

