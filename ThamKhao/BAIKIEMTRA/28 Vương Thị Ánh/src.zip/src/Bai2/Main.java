/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai2;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
// tong cac hang
public class Main {
    public static void main(String[] args) {
        int hang=0;
        List<List<Integer>> list=new ArrayList<>();
        try {
            Scanner scanner=new Scanner(new FileReader("src/Bai2/in.txt"));
            hang=scanner.nextInt();
           while (scanner.hasNext()){
               Scanner read=new Scanner(scanner.nextLine());
               ArrayList<Integer> tmp=new ArrayList<>();
               while (read.hasNext()){
                   tmp.add(read.nextInt());
               }
               list.add(tmp);
           }
            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        list.remove(0);
//        list.forEach(System.out::println);
        try {
            PrintWriter printWriter =new PrintWriter(new FileWriter("src/out.txt"));
            for (int i = 0; i <hang ; i++) {
        int sumhang=0;
                for (int j = 0; j <hang ; j++) {
                    sumhang+=list.get(i).get(j);
                }
                    printWriter.print(sumhang);
                printWriter.println();
            }
            printWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}