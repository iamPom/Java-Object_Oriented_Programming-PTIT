/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai1;

/**
 *
 * @author Admin
 */
public class Color extends Thread{
    private int num;

    public Color(int num) {
        this.num = num;
    }
    public void run(){
        int t=num;
        while(num>=0){
            if(t%2==0){
                System.out.println("\033[34m BLUE");
                t--;
            }
            else{
                System.out.println("\033[31m RED");
                t--;
            }
            
            try{
                sleep(1000);
            }catch(InterruptedException e){
                System.out.println(e);
            }
            
            num--;
            
        }
    }
}
