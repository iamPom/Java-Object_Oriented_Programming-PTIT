/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11;

/**
 *
 * @author ACER
 */
public class Thread3 extends Thread {
     private Data d;

    public Thread3(Data d) {
        this.d = d;
    }
    public void run(){
        synchronized(d){
            while(d.isRunning()){
                try{
                d.wait();
                }catch(InterruptedException e){
                    System.out.println(e);
                }
                if(d.getIndex()!=3){
                    d.notify();
                    continue;
                }
                int n = d.getN();
                System.out.print(n+": ");
                if(n%2==0) System.out.println("So chan");
                else System.out.println("So le");
                d.setIndex(1);
            }
            System.out.println("T3 stop");
            synchronized(d){
                stop();
            }
        }
    }
}
